package vehicles;

/*
 * LightSensor.java
 *
 * Created on September 11, 2003, 12:15 PM
 */

/**
 *
 * @author  levenick
 */
public class LightSensor extends AbstractSensor {

    public String mySource() {
        return "light";
    }
    
}
