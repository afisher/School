package vehicles;

/*
 * MySensors.java
 *
 * Created on September 5, 2003, 11:03 AM
 */

/**
 *
 * @author  wu_staff
 */
public class MySensors extends AbstractSensors {
    
    /** Creates a new instance of MySensors */
    public MySensors() {
        super();
    }
    
}
