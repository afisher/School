#!/bin/sh
exec java ga.GADriverFrame
